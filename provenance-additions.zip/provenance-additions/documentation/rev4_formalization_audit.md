# Formalization gap report — `typeD_decoupling-draft-rev4.tex` vs. the Lean project

Report only; no Lean code or the lakefile was changed. The whole project builds
(`lake build` succeeds, 8039 jobs). The definitive sorry inventory (term-position
`sorry`s, 16 total) is: `TypeDDecouplingLCLT` (6), `TypeDDecouplingEW` (6),
`TypeDDecouplingCrossover` (3), `TypeDDecouplingTracyWidom` (1). All other files
(`TypeDDecoupling`, `…Sector`, `…DressedMass`, `…Drift`, `…EqvarOrth`, `…Duality`,
`…DualPairWitness`) are sorry-free in their own bodies.

Classification legend: **[A]** formalized sorry-free (self-contained, standard axioms);
**[B]** formalized as an assembly with named hypotheses (sorry-free body, but takes cited
inputs as hypotheses and/or transitively inherits a leaf `sorry`); **[C]** stated but
sorried (honest `sorry`); **[D]** not represented as a Lean declaration.

## (1) Walk-through of sections 2–8

**§2 The model, measure, duality** (`TypeDDecoupling.lean`, `TypeDDecouplingDuality.lean`)
- `prop:measure` (reversible blocking measure, cited) — **[D]**: appears only in comments;
  its working content is captured by `lem:db`.
- `lem:db` (local detailed balance) — **[A]**: the concrete ν-weight relations
  (`ν(0,3)=q⁻⁴ν(3,0)`, species-swap, equal off-diagonal weights) are proved.
- `def:D` (orthonormal local basis) — represented as a definition (duality functions in
  `…Duality.lean` and `Fdual` in `…DressedMass.lean`); not a proof target.
- `thm:dual` (q-Krawtchouk self-duality), `cor:tri`, `lem:acr`, `prop:orth` — **[B]**:
  sorry-free assemblies conditional on the cited CFG20/REU duality inputs.

**§3 Exact current decoupling** (`TypeDDecoupling.lean`)
- `prop:decouple` (exact current decoupling, `current_decoupling`) — **[A]**.
- `prop:cross` (vanishing cross coefficients) — **[A]**.

**§4 Local CLTs for dual coordinates** (`TypeDDecouplingLCLT.lean`)
- `lem:free`, `lem:Rlclt`, `lem:Slclt` — **[C]** (the paper's own analytic proofs, sorried).
- `lem:KR` (Kolmogorov–Rogozin), `thm:karamata` (Karamata Tauberian) — **[C]** (cited classics).
- `lem:tau` (occupation-time asymptotics) — **[B]**: sorry-free body derived from
  `thm:karamata`, so it inherits that leaf.

**§5 Two-particle dual kernel bound** (`TypeDDecouplingLCLT.lean`)
- `lem:asep` (same-species channel) — **[B]**: assembled from the cited Green's-function
  formula; the steepest-descent decay `asepGreen_integral_decay` is the sorried leaf **[C]**.
- `thm:kernel` (type-D two-particle bound) — **[B]**: sorry-free assembly inheriting `lem:asep`.

**§6 Decoupled Edwards–Wilkinson limit** (`…EW.lean`, `…EqvarOrth.lean`, `…Sector.lean`, `…DressedMass.lean`, `…Drift.lean`)
- `lem:dynkin`, `thm:mp`, `thm:mitoma`, `prop:aldous`, `lem:gauss` — **[C]** (cited SPDE /
  tightness / martingale-problem classics, honest sorries).
- `lem:orth` (orthogonality to density fields) — **[A]** (`…EqvarOrth.lean`).
- `lem:eqvar` (equal-time variance) — **[A]** (`…EqvarOrth.lean`).
- `lem:sector` (corrected sector comparison) — **[A]** (`…Sector.lean`); fidelity in (2).
- `lem:Vprod` (product form of carré du champ) — **[A]** (`…DressedMass.lean`).
- `lem:dresseps` (exact dressing identity) — **[A]** (`…DressedMass.lean`, at fugacity 1).
- `lem:eps` (dressed mass negligible) — **[A]**: `DressedMass.dressedMass_bond_le` plus the
  sorry-free EW wrapper `lem_eps` producing `ε_N→0` with `ewDressedMass ≤ ε_N`.
- `prop:conc` (L² concentration of the cross bracket, condition X) — **[C]** (honest sorry).
- `prop:sym` (current ⟂ bound-pair mode) — **[B]** (assembly on cited inputs).
- `prop:drift` — **[B]**: quantitative finite-algebra core proved sorry-free in
  `…Drift.lean` (`drift_sbp_bound`, `corr_second_moment`); the EW `prop_drift` is sorry-free
  with the 𝒮′(ℝ) SPDE bridge taken as hypotheses `hpin`/`hpin_nonneg`.
- `thm:ewmain` (decoupled EW limit) — **[B]**: sorry-free assembly that genuinely wires in
  the corrected sector comparison (`Sector.hfac`, `lem_sector_transfer`) and the dressed
  mass (`lem_eps`), but transitively inherits the §6 leaf sorries (`prop_conc`, `thm_mp`,
  `thm_mitoma`, `prop_aldous`, `lem_gauss`).

**§7 Initial-condition crossover** (`…Crossover.lean`, `TypeDDecoupling.lean`)
- `thm:cross` (regime-A crossover) — **[B]**: sorry-free assembly inheriting
  `prop_twophase_mixture` and `lem_crossbridge`.
- `prop:struve` (Bessel–Struve correlation, literal I₀/L₀ form) — **[A]**.
- `lem:crossbridge` (dual pair computes species cross-correlation) — **[C]** (cited duality).
- `lem:split` — **[A]**; `lem:rebind` — **[A]**; `lem:occ` — **[A]**.
- `prop:twophase` (two-phase functional CLT), incl. `prop_twophase_mixture` — **[C]** (cited CLT).
- `lem:price` (Price–Sheppard) — **[A]**.
- `thm:closed` (closed form ρ(c)=(1−e⁻⁴ᶜ)/4c with limits/monotonicity/tail) — **[A]**.

**§8 Tracy–Widom regime** (`…TracyWidom.lean`, `TypeDDecoupling.lean`)
- `thm:marg` (Tracy–Widom marginals) — **[B]** (assembly reducing to cited single-species
  step-ASEP TW input via `prop:decouple`).
- `lem:tridual` (step-sector duality identities) — **[A]**.
- `thm:cov` (q-Laplace contact representation: `qmom_contact`/`qcov_contact`) — **[A]**.
- `prop:occ` (contact occupations of the relative walk) — **[A]**.
- `conj:cov` (linear covariance) — **[C]**, explicitly an open conjecture, not a proof target.

## (2) Statement-fidelity of the two newest correspondences

**Corrected sector lemma — `lem:sector` (rev4) vs. `TypeDDecoupling.Sector` (and EW wrappers).**
Faithful; the correction is captured. Specifically:
- (i) Conditional laws agree ↔ `condLaw_sector_const` — exact match (weights differing by a
  sector-constant factor induce identical particle-number-fiber conditionals).
- (ii) Two-sided bound ↔ `sector_comparison_single` + `sector_comparison_two`. The exact
  telescoping identity (`gfun_master`) reproduces the paper's cancellation of the linear term
  via `log(α/β)=−log(1−β)` at the compensated fugacity `β=α/(1+α)`, and the bound
  `|log(ν/ϖ)| ≤ 2·A·(1+8β/(1−β))` (single species), summed to `2(C₀(β₁)+C₀(β₂))` for two
  species, matches the paper's `logM=2(C₀(β₁)+C₀(β₂))` with `C₀(β)=…(1+8β/(1−β))`. The
  `8β/(1−β)` drift factor and the doubling from the normalisation-pinning argument
  (`log_ratio_pinned`) match exactly. **Minor note:** the paper's explicit numeral
  `18cK²` is not hard-coded; Lean carries the quadratic bound as an abstract parameter `A`
  with hypothesis `(−log q)·S² ≤ A` (with `q=1−c/N²`, `S≈2KN`, this instantiates to the
  paper's `Θ(cK²)`), so the Lean statement is strictly more general than the numeric form.
- (iii) Transfer inequality ↔ `correlation_transfer` (and the EW wrapper
  `lem_sector_transfer`): the per-sector Cauchy–Schwarz bound
  `|E_ν[f·Ph]| ≤ M·E_ϖ[f·Pf]^{1/2}·E_ϖ[h·Ph]^{1/2}` is proved, with the positive-
  semidefiniteness and per-sector Cauchy–Schwarz of the sector-preserving self-adjoint
  semigroup taken as named hypotheses (`hpsd`, `hCS`) rather than derived — i.e. this clause
  is **[A] with the semigroup properties as hypotheses**. No mismatch in constants or
  statement strength; the reweighting is correctly the finite `hfac` proportional to the
  paper's infinite q-Pochhammer form (constant cancels in every ratio).

**`lem:eps` chain (rev4) vs. `TypeDDecouplingDressedMass.lean`.** Faithful.
- `lem:Vprod` (`V_z=φ¹_z φ²_z`) ↔ `Vbond` is *defined* as the product and
  `Vbond_support_values` proves the values `1,q⁴,−q²,−q²` on `(3,0),(0,3),(1,2),(2,1)`
  matching `eq:Vdef` (the indicator form is verified via case values rather than as an
  equation between two separately-defined objects).
- `lem:dresseps` (`F^i_z−F^i_{z+1} = −q^{2(z−L_i)}φ^i_z`) ↔ `Fdual_diff` — exact match, but
  **specialised to fugacity α_i=β_i=1** (`Fdual = 1 − q^{2(w−N⁻)}η`). The paper's general
  β_i only rescales the four basis elements, which does not change their span or the
  projection distance, so this is WLOG for the estimate but is a fidelity narrowing worth
  recording.
- `eq:keyeps` (`A_z=q^{−2(L₁+L₂)}V_z`) ↔ `Vbond_sub_Az`
  (`V−A=(1−q^{−2(L₁+L₂)})V`), equivalent.
- Projection bound with `ε_N=(q^{−4ℓ(z)}−1)²`, `ℓ(z)=#{v∈Λ:v<z}` ↔ `dressedMass_bond_le`
  — exact match. **Strength note:** `dressedMass` is defined as the infimum over the
  bond-pair span of `‖V−A‖²`, and the Lean proof bounds it directly by exhibiting the
  explicit element `A_z`; it therefore does **not** need `prop:orth`'s orthogonality (the
  paper's route through the orthogonal projection). This makes the Lean statement slightly
  stronger/cleaner than the paper's argument, not weaker. The EW wrapper `lem_eps` then
  supplies `ε_N=O(N⁻²)→0`, matching the paper's `ε_N ≤ C(c,K)N⁻²`.

Overall: no substantive mismatches in constants, hypotheses, or statement strength for
either correspondence; the two documented narrowings (transfer clause assumes the semigroup
PSD/self-adjointness; dressing identity taken at fugacity 1) are mathematically WLOG for the
downstream estimates.

## (3) Not represented at all, with feasibility

- `prop:measure` (reversible blocking-measure identity, §2) — only its consequence `lem:db`
  is formalized. **Feasible-finite-algebra** (a detailed-balance product-measure computation).
- Finite-`n` generator / rate matrix `eq:nrates`, `eq:nparams` (model at finite `n`) — a
  definition, not encoded (the Lean model is at `n=∞`). **Feasible-finite-algebra** (a def;
  optionally re-derive `prop:decouple` at finite `n`).
- §9 asymmetry–exponent phase picture (`sec:phase`, `eq:alpha`) — descriptive, no theorem.
  **Research-grade / not a proof target** as stated.
- §9 numerical evidence (`sec:numerics`) — empirical simulation claims. **Research-grade**;
  only the finite decidable sub-claims (if any were isolated) would be feasible-finite-algebra.
- `conj:cov` (Corr(N₁,N₂) ≍ s^{−1/6}) — present as a sorried statement, explicitly open.
  **Research-grade** (open conjecture).
- Out-of-Mathlib objects (𝒮′(ℝ)-valued SPDE processes, OU stationarity, Mitoma/Aldous
  tightness, GUE/F₂ Tracy–Widom) are only *partially* represented, as `opaque` placeholders
  feeding the §6/§8 assemblies. **Feasible-with-hypotheses** for the wiring; the underlying
  theory is research-grade to build from scratch in Mathlib.

(The genuinely analytic items still carrying honest sorries — `lem:free/Rlclt/Slclt`,
`prop:conc`, `prop:twophase`, `lem:crossbridge` — ARE represented, as class **[C]** above,
so they are not listed here; they are the natural next targets in (4).)

## (4) Prioritized next formalization targets (≤3)

1. **`prop:conc` (L² concentration of the cross bracket, condition X).** Highest leverage:
   both of its inputs are now proved sorry-free (`lem_sector_transfer` from the corrected
   sector lemma and `lem_eps` from the dressed-mass bound), so finishing the concentration
   estimate would collapse the §6 decoupling condition (X) down to only cited classical
   black boxes. Feasible-with-hypotheses.
2. **The LCLT trio `lem:free` / `lem:Rlclt` / `lem:Slclt`.** These are the paper's own
   analytic engine (not cited results), and they gate both `thm:kernel` and the
   `N⁻²log(tN²)` term inside `prop:conc`. Proving even `lem:Slclt` (conditional
   concentration for the sum coordinate) removes the largest remaining self-authored
   analytic gap. Feasible-with-hypotheses.
3. **`lem:crossbridge` (dual pair computes the species cross-correlation).** It is the single
   duality identity, algebraic/finite in nature, that — together with the CLT input
   `prop_twophase_mixture` — is the last non-classical sorry gating `thm:cross`
   (`thm:closed` and `prop:struve` are already sorry-free). Feasible-with-hypotheses /
   feasible-finite-algebra.

