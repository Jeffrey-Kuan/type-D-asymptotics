# Formalization Guide — *Correlated and uncorrelated long-time asymptotics of type D ASEP*

**Lean 4 over Mathlib · 31 files · ≈13,800 lines · 670+ declarations · 2 `sorry`s** (state of 2026-07-08).

This document is the human reviewer's map of the formalization. It explains what each file contains, what is *proved*, what is *assumed* and under which convention, and where every paper result lives in the Lean source.

---

## 1. How to review this formalization

The Lean kernel has already checked every proof: if a declaration has no `sorry` and depends only on the standard axioms (`propext`, `Classical.choice`, `Quot.sound` — verified per headline theorem throughout), its proof is correct. **The human reviewer's job is fidelity, not correctness**:

1. **Do the statements say what the paper claims?** Read the theorem *statements* (quoted or referenced below), not the proof bodies.
2. **Are the definitions non-vacuous?** (This project caught a vacuous interface once — see catch #5 in §6.)
3. **What exactly do the hypothesis bundles assume?** Every bundle is documented field-by-field in its docstring; §5 inventories them.
4. **Are the remaining `sorry`s what they claim to be?** §7 lists both, each a named classical theorem.

The project's eight statement-level defects (§6) were all found by exactly this kind of reading — three of them by the formalization process itself.

## 2. Epistemic taxonomy

Every declaration falls into one of five classes; docstrings say which.

| Class | Meaning | Examples |
|---|---|---|
| **[P] Proved** | Sorry-free, standard axioms, no hypothesis beyond the mathematical ones | `kolmogorov_rogozin`, `levyContinuityℝ`, `lem_free` |
| **[B] Bundle-conditioned** | Proved from an explicitly documented, faithful, satisfiable hypothesis bundle carrying process-level facts (project convention: `hpin`, `hproc`, `hconc`, `htwo`, `hcont`, `hrenew`, Markov–Feller) | `prop_drift`, `prop_conc`, `prop_twophase`, `lem_crossbridge`, `lem_dynkin` |
| **[D] Definitional-with-citation** | An identification with a classical object is taken as the *definition*, with the cited literature named in the docstring | `asepKernel` (= Schütz's reflection formula), `dynkinBracketDef` (= ∫Γ; EK Ch. 4) |
| **[S] Sorried citation** | An honest black box standing for a named classical theorem | the two of §7 |
| **[C] Conjecture** | A named `Prop` with no truth claim | `covConjecture` |

## 3. Paper ↔ Lean dictionary (principal results)

| Paper | Lean declaration | File | Class |
|---|---|---|---|
| Thm 2.5(ii) duality interlacing | `thm_dual`, `cor_tri` | Duality | [B] (CFG20/REU inputs) |
| Prop 2.8 orthogonality | `prop_orth` | Duality | [B] |
| Prop 3.1 current decoupling (every *n*, real *qⁿ*) | `current_decoupling`, `current_decoupling_finiteN` | TypeDDecoupling, FiniteN | [P] |
| Prop 3.2 vanishing cross coefficients | `crossMobility_eq_zero`, `crossCompressibility_eq_zero` | TypeDDecoupling | [P] |
| Lem 4.1 kernel bound (CKS/Nash) | `lem_free` | LCLT (+CKS, CKS2, Nash, Semigroup) | [P] (with faithful `hp_le1`) |
| Lem 4.2 defected LCLT | `lem_Rlclt` | LCLT | [B] (`hrenew`) |
| Lem 4.3 Kolmogorov–Rogozin | `kolmogorov_rogozin` | LCLT (+KR) | [P] |
| Lem 4.4 skeleton concentration | `lem_Slclt` | LCLT (+KR) | [P] |
| Thm 4.5 Karamata (constant *L*) | `karamata_tauberian` | LCLT (+Karamata) | [P] (Tauberian direction) |
| Lem 4.6 occupation asymptotics | `lem_tau` | LCLT | [P] |
| Lem 5.1 same-species channel | `lem_asep` | LCLT (+Bethe) | [P] over [D] kernel |
| Thm 5.2 two-particle kernel bound | `thm_kernel` | LCLT | [B] |
| Lem 6.6* single-species EW | `lem_gauss` | EW (+BracketN) | [B] — proved as `thm_mp`'s single-field case; DG cited as the instantiated classical theorem |
| Lem 6.7 orthogonality | `lem_orth` (`expect_V_mul_barD_*`) | EW (+EqvarOrth) | [P] |
| Lem 6.8 equal-time variance | `lem_eqvar` (`expect_sq_le`) | EW (+EqvarOrth) | [P] |
| Lem 6.9 sector comparison (compensated fugacity) | `lem_sector`, `lem_sector_transfer` | EW (+Sector) | [P] |
| Lem 6.10/6.11 product & dressing identities | `Vbond_*`, `Fdual_diff` | DressedMass | [P] |
| Lem 6.12 dressed mass O(N⁻²) | `lem_eps` (`dressedMass_bond_le`) | EW (+DressedMass) | [P] |
| Prop 6.14 cross-bracket concentration | `prop_conc` (`conc_master`) | EW (+Conc) | [B] (`hproc`) |
| Cor 6.15 current ⊥ bound-pair | `prop_sym` | EW | [P] |
| Prop 6.16 drift | `prop_drift` (`drift_sbp_bound`, `corr_second_moment`) | EW (+Drift) | [B] (`hpin`) |
| Thm 6.2 martingale-problem characterization | `thm_mp` | EW (+MartingaleGaussian) | [B] (`hmp`; Gaussian/uniqueness content proved) |
| Thm 6.3/6.4 Mitoma & Aldous | `thm_mitoma`, `prop_aldous` | EW | [S] |
| Thm 6.5 decoupled EW limit | `thm_ewmain` | EW | [B] assembly |
| Prop 7.7 two-phase CLT + mixture | `prop_twophase`, `prop_twophase_mixture` | Crossover (+TwoPhase, Bridge) | [B] (`htwo`) |
| Lem 7.3 crossbridge (ℤ) | `lem_crossbridge` | Crossover (+Crossbridge, CrossbridgeLimit) | [B] (`hcont`; finite-L core [P]) |
| Lem 7.4/7.5 split & re-binding | `lem_split` content, `lem_rebind` | TypeDDecoupling, LCLT | [P] |
| Lem 7.6 Price–Sheppard | `price_sheppard` | TypeDDecoupling | [P] |
| Thm 7.8 closed form ρ(c) | `rhoCorr_*`, `expMin_mean_eq_rhoCorr` | TypeDDecoupling | [P] |
| Prop 7.2 Bessel–Struve form | `rhoStruve_bessel_struve` | TypeDDecoupling | [P] |
| Thm 7.1 crossover assembly | `thm_cross` | Crossover | [B] assembly |
| Thm 8.1 TW marginals | `thm_marg` | TracyWidom | [B] (BCS input) |
| Thm 8.3 q-Laplace decoupling | `qmom_contact`, `qcov_contact` | TypeDDecoupling | [P] |
| Prop 8.4 contact occupations | `prop_occ` | LCLT | [P] |
| Conj 8.5 linear covariance | `covConjecture` | TracyWidom | [C] |

\* Numbering follows rev4.

## 4. File-by-file tour

**Model & exact structure.**
- `TypeDDecoupling.lean` (1500+ lines) — the exact-computation heart: `rhoCorr` (the crossover correlation ρ(c) and its full calculus: monotone, limits, 1/(4c) tail), the n=∞ rate table and `current_decoupling`, detailed-balance two-point weights and the vanishing transport coefficients, Sheppard/Price (`orthantProb_eq`, `price_sheppard`), the Bessel–Struve closed form (`besselI0`/`struveL0` as explicit series, `rhoStruve_bessel_struve`), split-time asymptotics, and the regime-B telescopes `qmom_contact`/`qcov_contact`. All [P].
- `TypeDDecouplingFiniteN.lean` — finite-n rate table via the real-parameter `betaR/sigmaR` (analytic continuation in r = qⁿ), every-n current decoupling, the rescaled-limit lemmas, `rate_ratio_nfree`, the n-threshold facts. All [P].
- `TypeDDecouplingDuality.lean` — the duality interlacing/`GeneratorDual` framework: `thm_dual`, `cor_tri`, `lem_acr`, `prop_orth` as sorry-free assemblies from the cited CFG20/REU inputs [B].
- `TypeDDecouplingDualPairWitness.lean` — an explicit probability-space *witness* that the crossover hypothesis structures (`IsDualPairRescaling`) are satisfiable — the guard against vacuous hypotheses.

**§6 cross-noise apparatus.**
- `TypeDDecouplingEqvarOrth.lean` — the involution (`swapC`) mechanism: `expect_V_eq_zero`, the full orthogonality classification `expect_V_mul_barD_eq_zero(_two/_of_eq)`, equal-time variance `expect_sq_le`. [P]
- `TypeDDecouplingSector.lean` — the corrected Lemma 6.9 at compensated fugacity: telescoping `gfun_master`/`gfun_bound`, normalization pinning, `sector_comparison_two`, `correlation_transfer`. [P]
- `TypeDDecouplingDressedMass.lean` — Lemmas 6.10–6.12: the carré-du-champ product form, the exact dressing identity, projection bound `dressedMass_bond_le`. [P]
- `TypeDDecouplingDrift.lean`, `TypeDDecouplingConc.lean` — the quantitative cores of Props 6.16/6.14 (`drift_sbp_bound`, `corr_second_moment`; `conc_master` with the explicit three-term bound and `log₊`). [P], consumed via `hpin`/`hproc`.
- `TypeDDecouplingEW.lean` — the assembly file: the EW model structure, `prop_sym`, the §6 lemma wrappers, `prop_conc`, `prop_drift`, `lem_dynkin` [B], `thm_ewmain`, and the four remaining [S] leaves.
- `TypeDDecouplingDynkin.lean` — `dynkin_martingale` (a genuine `MeasureTheory.Martingale` from a Markov–Feller bundle) and `dynkin_L2` (E[MᶠMᵍ] = E∫Γ(f,g), general f,g). [B]/[P]
- `TypeDDecouplingBracketN.lean` — the WASEP (N)-computation: exact per-bond equilibrium factor (E[c_x] = (1+q²)χ, D = (1+q²)/2 consistent with `prop_drift`), the Riemann-sum mean → 2χD‖φ′‖², O(1/N) variance, L² time-concentration. [P], library-clean.
- `TypeDDecouplingMartingaleGaussian.lean` — the stopped-array adapter (discrete optional stopping + charFun transfer across vanishing events) and `martingale_charFun_gaussian`/`martingale_joint_charFun_gaussian`: martingale arrays with deterministic bracket have Gaussian (product) charFuns — the proved core of `thm_mp`. [P], library-clean.

**§4–5 kernel theory.**
- `TypeDDecouplingLCLT.lean` — the walk interfaces (`IsTransitionKernel`, `DriftlessReversibleWalk`, `OccupationWalk`), `lem_free` [P], `lem_Rlclt` [B], `kolmogorov_rogozin`/`lem_Slclt` [P], constant-L `karamata_tauberian` [P], `lem_tau` [P], `lem_asep`/`thm_kernel`, `prop_occ`.
- `TypeDDecouplingNash.lean` — the discrete Nash toolkit: `agmon_le`, `nash_ineq`, `nash_ode_bound`, `nash_pointwise_bound`. [P], library-clean.
- `TypeDDecouplingSemigroup.lean` — the bounded forward generator on ℓ¹ (`exists_forward_generator`, ‖A‖ ≤ 2Λ) and Widder groundwork. [P]
- `TypeDDecouplingCKS.lean` / `CKS2.lean` — the full CKS program on Q_t = exp(tA): positivity, mass, CK, reversibility, the proved energy identity `energy_hasDerivAt`, the y-uniform Nash ODE (κ = δc₁⁴/2c₂³), off-diagonal bound, weighted-Grönwall identification, `free_bound`. [P]
- `TypeDDecouplingKR.lean` — lattice Esseen inversion, symmetrization weights, gap integrals, `KR_abstract`, the measure-theory interface, `poisson_lower_tail` (c = (1−log 2)/2). [P], library-clean.
- `TypeDDecouplingKaramata.lean` — the constant-L Karamata Tauberian theorem: moment functionals, Stone–Weierstrass bridge, one-sided indicator sandwich, `tauberian_isEquivalent`. [P]
- `TypeDDecouplingBethe.lean` — `Fkern` (Fourier-defined asymmetric kernel) with full calculus; `Smatrix` **derived** from the contact condition (`Smatrix_boundary`); the reflection series `asepReflect` (ρ = r_L/r_R, shifts k) and its C/(1+t) decay. [P]; the identification `asepKernel := asepReflect` is [D] (Schütz).

**§7 crossover.**
- `TypeDDecouplingTwoPhase.lean` — `psiForm`, the fixed-changepoint two-phase CLT (+ u=0/u=1 edge cases), the mixture lemma, `expMin_mean`, the assembled random-changepoint theorem. [P]
- `TypeDDecouplingTwoPhaseBridge.lean` — **Lévy continuity on ℝ²** (`levyContinuityE2`, `tendstoInDistribution_of_charFun2`) via marginal tightness boxing. [P]
- `TypeDDecouplingCrossbridge.lean` — the finite-L crossbridge: `matrix_exp_intertwine`, block evaluation (k = 0), `crossbridge_finiteL` for every L (interlacing as its one named hypothesis). [P]/[B]
- `TypeDDecouplingCrossbridgeLimit.lean` — finite-box → full semigroup convergence via the finite-speed factorial-tail bound (`hitProb_finiteBox_tendsto`). [P], library-clean.
- `TypeDDecouplingCrossover.lean` — the assembly: `prop_twophase(_mixture)` [B via `htwo`], `lem_crossbridge` [B via `hcont`], `thm_cross`.

**General-purpose probability (the upstream shelf).**
- `TypeDDecouplingMartingaleCLT.lean` — **McLeish's martingale CLT**: the product-trick `core_charFun_tendsto` (hypothesis-free of Lévy), `mcleish_clt`, the bivariate `joint_charFun_tendsto`. [P]
- `TypeDDecouplingLevy.lean` — **Lévy's continuity theorem on ℝ** (`levyContinuityℝ`), proved outright; `mcleish_clt_unconditional`. [P]
- Plus Nash, KR, Karamata, Semigroup, CrossbridgeLimit, TwoPhaseBridge above — all deliberately free of project-specific imports.

**§8.** `TypeDDecouplingTracyWidom.lean` — `thm_marg` [B, BCS input], `covConjecture` [C]. `TypeDDecouplingTiers34.lean` — earlier assembly scaffolding.

## 5. Hypothesis-bundle ledger

Each bundle is documented field-by-field in its docstring; all are satisfiable (witnesses or standard-process facts) and each field cites its paper location.

| Bundle | Carried by | Contents (informal) |
|---|---|---|
| `hpin` | `prop_drift` | the 𝒮′ SPDE bridge for the drift limit |
| `hproc` | `prop_conc` | sector-transfer bound, kernel split, equal-time bound, stationarity identity |
| `hconc` | `thm_ewmain` | the `prop_conc` inputs threaded (with `ewEps`) |
| `htwo` | `prop_twophase(_mixture)` | discretized-array facts: MDS property, jump bound, bracket limits, planar charFun limit |
| `hcont` | `lem_crossbridge` | finite-L generators/duals, interlacing, η-side coupling convergence, encoded dual-side convergence |
| Markov–Feller | `lem_dynkin` | Markov property via semigroup, Kolmogorov identity, boundedness |
| `hrenew` | `lem_Rlclt` | semigroup identification + free-kernel decay + renewal representation (broader than ideal; documented) |
| `hp_le1` | `lem_free` | the a-priori kernel bound p ≤ 1 (interface gap; F3 precedent) |
| `hmp` (`MPPathBundle`) | `thm_mp` | path-space existence of the 𝒮′ limit from tightness + fdd charFun convergence (no Gaussian content — that is proved) |

## 6. Fidelity-catches ledger

Defects in the *paper or encoding* found by formalization pressure — the concrete answer to "why formalize":

1. **Lemma 6.9 was false as originally stated** (measure comparison at equal fugacities; M = e^{Θ(N)}). Corrected at compensated fugacity β = α/(1+α); numerically verified; the corrected lemma is [P].
2. **Prop 6.14's bound used bare log(tN²)** — false for t < N⁻². Fixed to log₊ in paper and Lean.
3. **`lem_Slclt`'s quantifier order** made it trivially satisfiable (C after M). Restated with the universal constant.
4. **`lem_Rlclt`'s quantifier order + window** made it near-trivial (C after q bounds t). Restated with C = C(K, q₀) uniform on [q₀, 1).
5. **`IsTransitionKernel` demanded nonnegativity for all real t** — unsatisfiable by any true kernel; every kernel-based lemma had been vacuously true. Restricted to t ≥ 0.
6. **`karamata_tauberian` quantified over non-measurable slowly-varying L** — exceeding the cited BGT theorem (whose UCT needs measurability). Restated at the constant-L strength actually consumed.
7. **`conj_cov` was a sorried theorem** — formally an *assumption* of an open conjecture. Re-encoded as a `Prop`-valued definition.
8. **`lem_gauss` took a free `Y` with no dynamical hypotheses** yet asserted OU convergence — a false-universal placeholder, not the paper's Lemma 6.6. Restated with the faithful single-species hypotheses and then *proved* as `thm_mp`'s single-field case.

## 7. The remaining `sorry`s (all in `TypeDDecouplingEW.lean`)

| Leaf | Stands for | Why it remains |
|---|---|---|
| `thm_mitoma` | Mitoma's tightness criterion | its *statement* needs the topology of D([0,T], 𝒮′) — absent from Lean |
| `prop_aldous` | Aldous's tightness criterion | its *statement* needs Skorokhod-space theory — absent from Lean |

## 8. Reproducibility

- Build: `lake build` at the pinned toolchain (`lean-toolchain`), Mathlib pinned in `lake-manifest.json` (v4.28.0).
- Axiom audit: every headline theorem checked to depend only on `propext`, `Classical.choice`, `Quot.sound` (no `sorryAx` outside the four leaves' dependents; `thm_ewmain` inherits exactly the §7 leaves).
- History: `ARISTOTLE_SUMMARY.md` records every formalization run with its routes and sanctioned fallbacks.
