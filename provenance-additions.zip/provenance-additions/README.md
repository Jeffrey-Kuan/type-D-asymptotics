# Formalization provenance: briefs, reports, and documentation

Artifacts from the Lean 4 formalization campaigns (June–July 2026).
The Lean code itself lives in the companion repository
[type-D-asymptotics-lean](https://github.com/Jeffrey-Kuan/type-D-asymptotics-lean),
which is CI-verified and documented by a
[blueprint](https://jeffrey-kuan.github.io/type-D-asymptotics-lean/blueprint/).

- `briefs/` — the 33 mathematical task briefs (LaTeX) written for the
  Aristotle CLI (Harmonic AI), specifying each formalization task: statements,
  sanctioned routes, fallback ladders, and fidelity constraints.
- `reports/` — the 19 task reports returned by Aristotle, documenting what
  was proved, the routes taken, statement adjustments, and counterexamples
  found (including the refutation of one brief's proposed architecture,
  task 8 of the Skorokhod campaign).
- `documentation/`
  - `FORMALIZATION_GUIDE.md` — reviewer's guide with the fidelity-catches
    ledger (current through the state before the Skorokhod campaign's end;
    a refresh is planned).
  - `lean_translation.pdf` / `.tex` + `translation_fragments/` — a literal
    English rendering of the Lean files (state as of Skorokhod task 5;
    later files not yet covered).
  - `rev4_formalization_audit.md` — statement-fidelity audit of the paper
    against the Lean tree.
  - `blueprint_content.tex` — early draft of the blueprint, superseded by
    the live one in the companion repository.
